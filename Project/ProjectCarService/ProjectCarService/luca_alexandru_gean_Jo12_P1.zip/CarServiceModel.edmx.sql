
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 03/21/2019 08:07:58
-- Generated from EDMX file: D:\Faculty\DotNETNextLevel\Project2\ProjectCarService\ProjectCarService\CarServiceModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [ServiceCar];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_ClientAuto]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Auto] DROP CONSTRAINT [FK_ClientAuto];
GO
IF OBJECT_ID(N'[dbo].[FK_ClientComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Comanda] DROP CONSTRAINT [FK_ClientComanda];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoSasiu]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Auto] DROP CONSTRAINT [FK_AutoSasiu];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Comanda] DROP CONSTRAINT [FK_AutoComanda];
GO
IF OBJECT_ID(N'[dbo].[FK_MecanicDetaliuComanda_Mecanic]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MecanicDetaliuComanda] DROP CONSTRAINT [FK_MecanicDetaliuComanda_Mecanic];
GO
IF OBJECT_ID(N'[dbo].[FK_MecanicDetaliuComanda_DetaliuComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MecanicDetaliuComanda] DROP CONSTRAINT [FK_MecanicDetaliuComanda_DetaliuComanda];
GO
IF OBJECT_ID(N'[dbo].[FK_MaterialDetaliuComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Material] DROP CONSTRAINT [FK_MaterialDetaliuComanda];
GO
IF OBJECT_ID(N'[dbo].[FK_ImageDetaliuComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Imagine] DROP CONSTRAINT [FK_ImageDetaliuComanda];
GO
IF OBJECT_ID(N'[dbo].[FK_OperatieDetaliuComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Operatie] DROP CONSTRAINT [FK_OperatieDetaliuComanda];
GO
IF OBJECT_ID(N'[dbo].[FK_DetaliuComandaComanda]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DetaliuComanda] DROP CONSTRAINT [FK_DetaliuComandaComanda];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Client]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Client];
GO
IF OBJECT_ID(N'[dbo].[Auto]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Auto];
GO
IF OBJECT_ID(N'[dbo].[Sasiu]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Sasiu];
GO
IF OBJECT_ID(N'[dbo].[Mecanic]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Mecanic];
GO
IF OBJECT_ID(N'[dbo].[Material]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Material];
GO
IF OBJECT_ID(N'[dbo].[Imagine]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Imagine];
GO
IF OBJECT_ID(N'[dbo].[DetaliuComanda]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DetaliuComanda];
GO
IF OBJECT_ID(N'[dbo].[Operatie]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Operatie];
GO
IF OBJECT_ID(N'[dbo].[Comanda]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Comanda];
GO
IF OBJECT_ID(N'[dbo].[MecanicDetaliuComanda]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MecanicDetaliuComanda];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Client'
CREATE TABLE [dbo].[Client] (
    [ClientId] int IDENTITY(1,1) NOT NULL,
    [Nume] nvarchar(15)  NOT NULL,
    [Prenume] nvarchar(15)  NOT NULL,
    [Adresa] nvarchar(50)  NOT NULL,
    [Localitate] nvarchar(10)  NOT NULL,
    [Judet] nvarchar(10)  NOT NULL,
    [Telefon] nvarchar(13)  NULL,
    [Email] nvarchar(50)  NULL
);
GO

-- Creating table 'Auto'
CREATE TABLE [dbo].[Auto] (
    [AutoId] int IDENTITY(1,1) NOT NULL,
    [NumarAuto] nvarchar(10)  NOT NULL,
    [SerieSasiu] nvarchar(25)  NOT NULL,
    [SasiuSasiuId] int  NOT NULL,
    [ClientClientId] int  NOT NULL,
    [Sasiu_SasiuId] int  NOT NULL
);
GO

-- Creating table 'Sasiu'
CREATE TABLE [dbo].[Sasiu] (
    [SasiuId] int IDENTITY(1,1) NOT NULL,
    [CodSasiu] nvarchar(2)  NOT NULL,
    [Denumire] nvarchar(25)  NOT NULL
);
GO

-- Creating table 'Mecanic'
CREATE TABLE [dbo].[Mecanic] (
    [MecanicId] int IDENTITY(1,1) NOT NULL,
    [Nume] nvarchar(15)  NOT NULL,
    [Prenume] nvarchar(15)  NOT NULL
);
GO

-- Creating table 'Material'
CREATE TABLE [dbo].[Material] (
    [MaterialId] int IDENTITY(1,1) NOT NULL,
    [Denumire] nvarchar(50)  NOT NULL,
    [Cantitate] decimal(2,0)  NOT NULL,
    [Pret] decimal(2,0)  NOT NULL,
    [DataAprovizionare] datetimeoffset  NOT NULL,
    [DetaliuComanda_DetaliuComandaId] int  NOT NULL
);
GO

-- Creating table 'Imagine'
CREATE TABLE [dbo].[Imagine] (
    [ImagineId] int IDENTITY(1,1) NOT NULL,
    [Titlu] nvarchar(15)  NOT NULL,
    [Descriere] nvarchar(256)  NOT NULL,
    [Data] datetimeoffset  NOT NULL,
    [Foto] tinyint  NOT NULL,
    [DetaliuComanda_DetaliuComandaId] int  NOT NULL
);
GO

-- Creating table 'DetaliuComanda'
CREATE TABLE [dbo].[DetaliuComanda] (
    [DetaliuComandaId] int IDENTITY(1,1) NOT NULL,
    [ImageId] nvarchar(max)  NULL,
    [Comanda_ComandaId] int  NOT NULL
);
GO

-- Creating table 'Operatie'
CREATE TABLE [dbo].[Operatie] (
    [OperatieId] int IDENTITY(1,1) NOT NULL,
    [Denumire] nvarchar(256)  NOT NULL,
    [TimpExecutie] decimal(2,0)  NOT NULL,
    [DetaliuComanda_DetaliuComandaId] int  NOT NULL
);
GO

-- Creating table 'Comanda'
CREATE TABLE [dbo].[Comanda] (
    [ComandaId] int IDENTITY(1,1) NOT NULL,
    [StareComanda] smallint  NOT NULL,
    [DataSystem] datetimeoffset  NOT NULL,
    [DataProgramare] datetimeoffset  NOT NULL,
    [DataFinalizare] datetimeoffset  NULL,
    [KmBord] int  NULL,
    [Descriere] nvarchar(max)  NOT NULL,
    [ValoarePise] decimal(2,0)  NULL,
    [ClientClientId] int  NOT NULL,
    [AutoAutoId] int  NOT NULL
);
GO

-- Creating table 'MecanicDetaliuComanda'
CREATE TABLE [dbo].[MecanicDetaliuComanda] (
    [Mecanics_MecanicId] int  NOT NULL,
    [DetaliuComandas_DetaliuComandaId] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [ClientId] in table 'Client'
ALTER TABLE [dbo].[Client]
ADD CONSTRAINT [PK_Client]
    PRIMARY KEY CLUSTERED ([ClientId] ASC);
GO

-- Creating primary key on [AutoId] in table 'Auto'
ALTER TABLE [dbo].[Auto]
ADD CONSTRAINT [PK_Auto]
    PRIMARY KEY CLUSTERED ([AutoId] ASC);
GO

-- Creating primary key on [SasiuId] in table 'Sasiu'
ALTER TABLE [dbo].[Sasiu]
ADD CONSTRAINT [PK_Sasiu]
    PRIMARY KEY CLUSTERED ([SasiuId] ASC);
GO

-- Creating primary key on [MecanicId] in table 'Mecanic'
ALTER TABLE [dbo].[Mecanic]
ADD CONSTRAINT [PK_Mecanic]
    PRIMARY KEY CLUSTERED ([MecanicId] ASC);
GO

-- Creating primary key on [MaterialId] in table 'Material'
ALTER TABLE [dbo].[Material]
ADD CONSTRAINT [PK_Material]
    PRIMARY KEY CLUSTERED ([MaterialId] ASC);
GO

-- Creating primary key on [ImagineId] in table 'Imagine'
ALTER TABLE [dbo].[Imagine]
ADD CONSTRAINT [PK_Imagine]
    PRIMARY KEY CLUSTERED ([ImagineId] ASC);
GO

-- Creating primary key on [DetaliuComandaId] in table 'DetaliuComanda'
ALTER TABLE [dbo].[DetaliuComanda]
ADD CONSTRAINT [PK_DetaliuComanda]
    PRIMARY KEY CLUSTERED ([DetaliuComandaId] ASC);
GO

-- Creating primary key on [OperatieId] in table 'Operatie'
ALTER TABLE [dbo].[Operatie]
ADD CONSTRAINT [PK_Operatie]
    PRIMARY KEY CLUSTERED ([OperatieId] ASC);
GO

-- Creating primary key on [ComandaId] in table 'Comanda'
ALTER TABLE [dbo].[Comanda]
ADD CONSTRAINT [PK_Comanda]
    PRIMARY KEY CLUSTERED ([ComandaId] ASC);
GO

-- Creating primary key on [Mecanics_MecanicId], [DetaliuComandas_DetaliuComandaId] in table 'MecanicDetaliuComanda'
ALTER TABLE [dbo].[MecanicDetaliuComanda]
ADD CONSTRAINT [PK_MecanicDetaliuComanda]
    PRIMARY KEY CLUSTERED ([Mecanics_MecanicId], [DetaliuComandas_DetaliuComandaId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [ClientClientId] in table 'Auto'
ALTER TABLE [dbo].[Auto]
ADD CONSTRAINT [FK_ClientAuto]
    FOREIGN KEY ([ClientClientId])
    REFERENCES [dbo].[Client]
        ([ClientId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClientAuto'
CREATE INDEX [IX_FK_ClientAuto]
ON [dbo].[Auto]
    ([ClientClientId]);
GO

-- Creating foreign key on [ClientClientId] in table 'Comanda'
ALTER TABLE [dbo].[Comanda]
ADD CONSTRAINT [FK_ClientComanda]
    FOREIGN KEY ([ClientClientId])
    REFERENCES [dbo].[Client]
        ([ClientId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClientComanda'
CREATE INDEX [IX_FK_ClientComanda]
ON [dbo].[Comanda]
    ([ClientClientId]);
GO

-- Creating foreign key on [Sasiu_SasiuId] in table 'Auto'
ALTER TABLE [dbo].[Auto]
ADD CONSTRAINT [FK_AutoSasiu]
    FOREIGN KEY ([Sasiu_SasiuId])
    REFERENCES [dbo].[Sasiu]
        ([SasiuId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoSasiu'
CREATE INDEX [IX_FK_AutoSasiu]
ON [dbo].[Auto]
    ([Sasiu_SasiuId]);
GO

-- Creating foreign key on [AutoAutoId] in table 'Comanda'
ALTER TABLE [dbo].[Comanda]
ADD CONSTRAINT [FK_AutoComanda]
    FOREIGN KEY ([AutoAutoId])
    REFERENCES [dbo].[Auto]
        ([AutoId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoComanda'
CREATE INDEX [IX_FK_AutoComanda]
ON [dbo].[Comanda]
    ([AutoAutoId]);
GO

-- Creating foreign key on [Mecanics_MecanicId] in table 'MecanicDetaliuComanda'
ALTER TABLE [dbo].[MecanicDetaliuComanda]
ADD CONSTRAINT [FK_MecanicDetaliuComanda_Mecanic]
    FOREIGN KEY ([Mecanics_MecanicId])
    REFERENCES [dbo].[Mecanic]
        ([MecanicId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [DetaliuComandas_DetaliuComandaId] in table 'MecanicDetaliuComanda'
ALTER TABLE [dbo].[MecanicDetaliuComanda]
ADD CONSTRAINT [FK_MecanicDetaliuComanda_DetaliuComanda]
    FOREIGN KEY ([DetaliuComandas_DetaliuComandaId])
    REFERENCES [dbo].[DetaliuComanda]
        ([DetaliuComandaId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MecanicDetaliuComanda_DetaliuComanda'
CREATE INDEX [IX_FK_MecanicDetaliuComanda_DetaliuComanda]
ON [dbo].[MecanicDetaliuComanda]
    ([DetaliuComandas_DetaliuComandaId]);
GO

-- Creating foreign key on [DetaliuComanda_DetaliuComandaId] in table 'Material'
ALTER TABLE [dbo].[Material]
ADD CONSTRAINT [FK_MaterialDetaliuComanda]
    FOREIGN KEY ([DetaliuComanda_DetaliuComandaId])
    REFERENCES [dbo].[DetaliuComanda]
        ([DetaliuComandaId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MaterialDetaliuComanda'
CREATE INDEX [IX_FK_MaterialDetaliuComanda]
ON [dbo].[Material]
    ([DetaliuComanda_DetaliuComandaId]);
GO

-- Creating foreign key on [DetaliuComanda_DetaliuComandaId] in table 'Imagine'
ALTER TABLE [dbo].[Imagine]
ADD CONSTRAINT [FK_ImageDetaliuComanda]
    FOREIGN KEY ([DetaliuComanda_DetaliuComandaId])
    REFERENCES [dbo].[DetaliuComanda]
        ([DetaliuComandaId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ImageDetaliuComanda'
CREATE INDEX [IX_FK_ImageDetaliuComanda]
ON [dbo].[Imagine]
    ([DetaliuComanda_DetaliuComandaId]);
GO

-- Creating foreign key on [DetaliuComanda_DetaliuComandaId] in table 'Operatie'
ALTER TABLE [dbo].[Operatie]
ADD CONSTRAINT [FK_OperatieDetaliuComanda]
    FOREIGN KEY ([DetaliuComanda_DetaliuComandaId])
    REFERENCES [dbo].[DetaliuComanda]
        ([DetaliuComandaId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_OperatieDetaliuComanda'
CREATE INDEX [IX_FK_OperatieDetaliuComanda]
ON [dbo].[Operatie]
    ([DetaliuComanda_DetaliuComandaId]);
GO

-- Creating foreign key on [Comanda_ComandaId] in table 'DetaliuComanda'
ALTER TABLE [dbo].[DetaliuComanda]
ADD CONSTRAINT [FK_DetaliuComandaComanda]
    FOREIGN KEY ([Comanda_ComandaId])
    REFERENCES [dbo].[Comanda]
        ([ComandaId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DetaliuComandaComanda'
CREATE INDEX [IX_FK_DetaliuComandaComanda]
ON [dbo].[DetaliuComanda]
    ([Comanda_ComandaId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------