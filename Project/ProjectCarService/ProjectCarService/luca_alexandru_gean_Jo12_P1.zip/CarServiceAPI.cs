﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectCarService
{
    public class CarServiceAPI
    {
        CarServiceModelContainer context = new CarServiceModelContainer();

        public void AddClient(Client client) 
        {
                context.Client.Add(client);
                context.SaveChanges();
        }

        public void AddAuto(Auto auto)
        {
            context.Auto.Add(auto);
            context.SaveChanges();
        }

        public void AddComanda(Comanda comanda)
        {
            context.Comanda.Add(comanda);
            context.SaveChanges();
        }

        public void AddDetaliuComanda(DetaliuComanda detaliuComanda)
        {
            context.DetaliuComanda.Add(detaliuComanda);
            context.SaveChanges();
        }

        public void AddImagine(Imagine imagine)
        {
            context.Imagine.Add(imagine);
            context.SaveChanges();
        }

        public void AddMaterial(Material material)
        {
            context.Material.Add(material);
            context.SaveChanges();
        }

        public void AddMecanic(Mecanic mecanic)
        {
            context.Mecanic.Add(mecanic);
            context.SaveChanges();
        }

        public void AddOperatie(Operatie operatie)
        {
            context.Operatie.Add(operatie);
            context.SaveChanges();
        }

        public void AddSasiu(Sasiu sasiu)
        {
            context.Sasiu.Add(sasiu);
            context.SaveChanges();
        }

        public void AddAuto(int clientId, Sasiu sasiu, string nrTarga, string serieSasiu)
        {
            if (serieSasiu[6] != sasiu.CodSasiu[0] || serieSasiu[7] != sasiu.CodSasiu[1])
            {
                if (context.Auto.SingleOrDefault(x => x.NumarAuto == nrTarga) != null)
                {
                    return;
                }
            }
            context.Auto.Add(new Auto {
                NumarAuto = nrTarga,
                SasiuSasiuId = sasiu.SasiuId,
                SerieSasiu = serieSasiu
            });
            context.Sasiu.Add(sasiu);
            context.SaveChanges();
        }

        /// <summary>
        ///StareComanda = 1 => in Asteptare
        ///StareComanda = 2 => executata
        ///StareComanda = 3 => Refuzata la executie
        /// </summary>
        public void AddComanda(int idClient, int autoId, int kmBord, DateTimeOffset dataProgramare, string descriere)
        {
            if (dataProgramare < DateTimeOffset.Now) return;
            context.Comanda.Add(new Comanda {
                StareComanda = 1,
                DataSystem = DateTimeOffset.Now,
                DataProgramare = dataProgramare,
                KmBord = kmBord,
                Descriere = descriere,
                ClientClientId = idClient,
                AutoAutoId = autoId,
                Client = GetClient(idClient),
                Auto = context.Auto.SingleOrDefault(x => x.AutoId == autoId)
            });
            context.SaveChanges();


        }

        public List<Auto> GetAllAuto()
        {
            return context.Auto.ToList();
        }

        public List<Client> GetAllClients()
        {
            return context.Client.ToList();
        }

        public List<Comanda> GetAllComands()
        {
            return context.Comanda.ToList();
        }

        public List<Material> GetAllMaterials()
        {
            return context.Material.ToList();
        }

        public List<Mecanic> GetAllMecanics()
        {
            return context.Mecanic.ToList();
        }

        public List<DetaliuComanda> GetAllDetailsCommands()
        {
            return context.DetaliuComanda.ToList();
        }

        public List<Imagine> GetAllImagies()
        {
            return context.Imagine.ToList();
        }

        public List<Operatie> GetOperations()
        {
            return context.Operatie.ToList();
        }

        public List<Sasiu> GetAllChassis()
        {
            return context.Sasiu.ToList();
        }

        public Client GetClient(int id)
        {
            return context.Client.SingleOrDefault(x => x.ClientId == id);
        }

        public Sasiu GetSasiuByAuto(int autoId)
        {
            return context.Sasiu.SingleOrDefault(x => x.SasiuId == autoId);
        }

        public Sasiu GetSasiu(int id)
        {
            return context.Sasiu.SingleOrDefault(x => x.SasiuId == id);
        }

        public Auto GetAuto(int id)
        {
            return context.Auto.SingleOrDefault(x => x.AutoId == id);
        }

        public Comanda GetComanda(int id)
        {
            return context.Comanda.SingleOrDefault(x => x.ComandaId == id);
        }

        public DetaliuComanda GetDetaliuComanda(int id)
        {
            return context.DetaliuComanda.SingleOrDefault(x => x.DetaliuComandaId == id);
        }

        public Imagine GetImagine(int id)
        {
            return context.Imagine.SingleOrDefault(x => x.ImagineId == id);
        }

        public Material GetMaterial(int id)
        {
            return context.Material.SingleOrDefault(x => x.MaterialId == id);
        }

        public Mecanic GetMecanic(int id)
        {
            return context.Mecanic.SingleOrDefault(x => x.MecanicId == id);
        }

        public Operatie GetOperatie(int id)
        {
            return context.Operatie.SingleOrDefault(x => x.OperatieId == id);
        }

        public void DeleteClientAutoSasiu(int idClient)
        {
            Sasiu sasiu;
            Client client = context.Client.SingleOrDefault(x => x.ClientId == idClient);
            if (client == null) return;

            List<Auto> autos = context.Auto.Where(x => x.ClientClientId == idClient).ToList();
            if (autos == null) return;
            foreach (var auto in autos)
            {
                sasiu = context.Sasiu.SingleOrDefault(s => s.SasiuId == auto.SasiuSasiuId);
                context.Sasiu.Remove(sasiu);
                context.SaveChanges();
                context.Auto.Remove(auto);
                context.SaveChanges();
            }

            context.Client.Remove(client);
            context.SaveChanges();
        }

        public void DeleteClient(int clientId)
        {
            Client client = context.Client.SingleOrDefault(c => c.ClientId == clientId);
            if (client == null) return;
            context.Client.Remove(client);
            context.SaveChanges();
        }

        public void DeleteAuto(int autoId)
        {
            Auto auto = context.Auto.SingleOrDefault(a => a.AutoId == autoId);
            if (auto == null) return;
            context.Auto.Remove(auto);
            context.SaveChanges();
        }

        public void DeleteComanda(int comandaId)
        {
            Comanda comanda = context.Comanda.SingleOrDefault(c => c.ComandaId == comandaId);
            if (comanda == null) return;
            context.Comanda.Remove(comanda);
            context.SaveChanges();
        }

        public void DeleteMaterial(int materialId)
        {
            Material material = context.Material.SingleOrDefault(m => m.MaterialId == materialId);
            if (material == null) return;
            context.Material.Remove(material);
            context.SaveChanges();
        }

        public void DeleteMecanic(int mecanicId)
        {
            Mecanic mecanic = context.Mecanic.SingleOrDefault(m => m.MecanicId == mecanicId);
            if (mecanic == null) return;
            context.Mecanic.Remove(mecanic);
            context.SaveChanges();
        }

        public void DeleteOperatie(int operatieId)
        {
            Operatie operatie = context.Operatie.SingleOrDefault(o => o.OperatieId == operatieId);
            if (operatie == null) return;
            context.Operatie.Remove(operatie);
            context.SaveChanges();
        }

        public void DeleteSasiu(int sasiuId)
        {
            Sasiu sasiu = context.Sasiu.SingleOrDefault(s => s.SasiuId== sasiuId);
            if (sasiu == null) return;
            context.Sasiu.Remove(sasiu);
            context.SaveChanges();
        }

        public void DeleteDetaliuComanda(int detaliuComandaId)
        {
            DetaliuComanda detaliuComanda = context.DetaliuComanda.SingleOrDefault(d => d.DetaliuComandaId == detaliuComandaId);
            if (detaliuComanda == null) return;
            context.DetaliuComanda.Remove(detaliuComanda);
            context.SaveChanges();
        }

        public void DeleteImage(int imagineId)
        {
            Imagine imagine = context.Imagine.SingleOrDefault(i => i.ImagineId == imagineId);
            if (imagine == null) return;
            context.Imagine.Remove(imagine);
            context.SaveChanges();
        }

        public void UpdateClient(Client client)
        {
            var result = context.Client.SingleOrDefault(c => c.ClientId == client.ClientId);

            if (result == null) return;

            result = client;
            context.SaveChanges();
        }

        public void UpdateAuto(Auto auto)
        {
            var result = context.Auto.SingleOrDefault(c => c.AutoId == auto.AutoId);

            if (result == null) return;

            result = auto;
            context.SaveChanges();
        }

        public void UpdateComanda(Comanda comanda)
        {
            var result = context.Comanda.SingleOrDefault(c => c.ComandaId == comanda.ComandaId);

            if (result == null) return;

            result = comanda;
            context.SaveChanges();
        }

        public void UpdateDetaliuComanda(DetaliuComanda detaliuComanda)
        {
            var result = context.DetaliuComanda.SingleOrDefault(
                c => c.DetaliuComandaId == detaliuComanda.DetaliuComandaId);

            if (result == null) return;

            result = detaliuComanda;
            context.SaveChanges();
        }

        public void UpdateImaine(Imagine imagine)
        {
            var result = context.Imagine.SingleOrDefault(
                c => c.ImagineId == imagine.ImagineId);

            if (result == null) return;

            result = imagine;
            context.SaveChanges();
        }

        public void UpdateMaterial(Material material)
        {
            var result = context.Material.SingleOrDefault(
                c => c.MaterialId == material.MaterialId);

            if (result == null) return;

            result = material;
            context.SaveChanges();
        }
        
        public void UpdateMecanic(Mecanic mecanic)
        {
            var result = context.Mecanic.SingleOrDefault(
                c => c.MecanicId == mecanic.MecanicId);

            if (result == null) return;

            result = mecanic;
            context.SaveChanges();
        }

        public void UpdateOperatie(Operatie operatie)
        {
            var result = context.Operatie.SingleOrDefault(
                c => c.OperatieId == operatie.OperatieId);

            if (result == null) return;

            result = operatie;
            context.SaveChanges();
        }

        public void UpdateSasiu(Sasiu sasiu)
        {
            var result = context.Sasiu.SingleOrDefault(
                c => c.SasiuId == sasiu.SasiuId);

            if (result == null) return;

            result = sasiu;
            context.SaveChanges();
        }
    }
}
